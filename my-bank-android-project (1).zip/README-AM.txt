MY BANK DEMO — Android project

ይህ ፕሮጀክት የትምህርት/ሙከራ ማሳያ ብቻ ነው። ከCBE ወይም ከሌላ ባንክ ጋር ግንኙነት የለውም።
እውነተኛ ገንዘብ አያስተላልፍም፤ በመሣሪያው ላይ የሚታዩ ቁጥሮች የሙከራ ውሂብ ናቸው።

APK ለማውጣት:
1. ይህን ZIP ወደ GitHub repository ጫን (Upload files).
2. በGitHub ውስጥ Actions ክፈት.
3. Build Android APK workflow አስኪድ (Run workflow).
4. ስራው ሲጠናቀቅ Artifacts ውስጥ my-bank-demo-apk አውርድ.
5. ZIP artifact ክፈትና app-debug.apk ወደ Android ስልክ አስተላልፍ።

ለመጫን APK-ውን ክፈት። ስልኩ ከሚጠይቅ የዚያን ፋይል ምንጭ መጫን ፍቀድ።
